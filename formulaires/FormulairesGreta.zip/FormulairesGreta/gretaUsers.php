
<?php

echo "Votre nom : ".$_POST['lastName']."<br>";
echo "Votre Prénom : ".$_POST['firstName']."<br>";
echo "Votre adresse mail : ".$_POST['eMail']."<br>";
echo "Mot de passe : ".$_POST['password']."<br>";
echo "Controle du Mot de passe : ".$_POST['controlPassword']."<br>";


?>